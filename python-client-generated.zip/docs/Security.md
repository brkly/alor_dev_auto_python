# Security

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**symbol** | **str** | Тикер (Код финансового инструмента) | [optional] 
**shortname** | **str** | Краткое наименование инструмента | [optional] 
**description** | **str** | Краткое описание инструмента | [optional] 
**exchange** | **str** | Биржа | [optional] 
**type** | **str** | Тип | [optional] 
**lotsize** | **float** | Размер лота | [optional] 
**facevalue** | **float** | Номинальная стоимость | [optional] 
**cfi_code** | **str** | Тип ценной бумаги согласно стандарту ISO 10962 | [optional] 
**cancellation** | **str** | Дата и время (UTC) окончания действия | [optional] 
**minstep** | **float** | Минимальный шаг цены | [optional] 
**rating** | **float** |  | [optional] 
**marginbuy** | **float** | Цена маржинальной покупки (заемные средства) | [optional] 
**marginsell** | **float** | Цена маржинальной продажи (заемные средства) | [optional] 
**marginrate** | **float** | Отношение цены маржинальной покупки к цене последней сделки | [optional] 
**pricestep** | **float** | Минимальный шаг цены, выраженный в рублях | [optional] 
**price_max** | **float** | Максимальная цена | [optional] 
**price_min** | **float** | Минимальная цена | [optional] 
**theor_price** | **float** |  | [optional] 
**theor_price_limit** | **float** |  | [optional] 
**volatility** | **float** | Волативность | [optional] 
**currency** | **str** | Валюта | [optional] 
**isin** | **str** | Идентификатор ценной бумаги согласно стандарту ISO 6166 | [optional] 
**_yield** | **str** |  | [optional] 
**primary_board** | **str** | Код режима торгов | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

