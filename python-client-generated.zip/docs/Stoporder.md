# Stoporder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** | Уникальный идентификатор стоп-заявки | [optional] 
**symbol** | **str** | Тикер (Код финансового инструмента) | [optional] 
**exchange** | **str** | Биржа | [optional] 
**broker_symbol** | **str** | Пара Биржа:Тикер | [optional] 
**type** | **str** | Тип заявки | [optional] 
**stop_price** | **float** | Условная цена | [optional] 
**side** | **str** | Направление сделки. Купля либо продажа. | [optional] 
**status** | **str** | Статус исполнения. На исполнении, исполнена, отменена, отклонена. | [optional] 
**end_time** | **str** | Время действия заявки (UTC) | [optional] 
**qty** | **float** | Количество | [optional] 
**filled_qty_batch** | **float** | Количество исполненных | [optional] 
**price** | **float** | Цена(Лимит) | [optional] 
**existing** | **bool** | True - для данных из \&quot;снепшота\&quot;, то есть из истории. False - для новых событий | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

