# Alltrade

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Уникальный идентификатор. | [optional] 
**orderno** | **int** | Идентификатор заявки | [optional] 
**symbol** | **str** | Тикер (Код финансового инструмента). \&quot;[N/A]\&quot; используется если symbol не определен. | [optional] 
**qty** | **int** | Количество | [optional] 
**price** | **float** | Цена | [optional] 
**time** | **str** | Дата и время (UTC) закрытия заявки | [optional] 
**timestamp** | **int** | Время (UTC) в формате Unix Time Milliseconds | [optional] 
**side** | **str** | Направление агрессивной заявки. Поле может быть пустым | [optional] 
**oi** | **int** | Открытый интерес (open interest). Если не поддерживается инстурментом - значение 0. | [optional] 
**existing** | **bool** | True - для данных из \&quot;снепшота\&quot;, то есть из истории. False - для новых событий | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

