# BodyrequestOrdersActionsStopUser

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **str** | Идентификатор аккаунта пользователя | [optional] 
**portfolio** | **str** | Идентификатор клиентского портфеля | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

