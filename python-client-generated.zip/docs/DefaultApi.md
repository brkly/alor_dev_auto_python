# swagger_client.DefaultApi

All URIs are relative to *https://apidev.alor.ru*

Method | HTTP request | Description
------------- | ------------- | -------------
[**command_api_v2clientordersactionslimit**](DefaultApi.md#command_api_v2clientordersactionslimit) | **POST** /commandapi/warptrans/TRADE/v2/client/orders/actions/limit | Создание лимитной заявки
[**command_api_v2clientordersactionslimitput**](DefaultApi.md#command_api_v2clientordersactionslimitput) | **PUT** /commandapi/warptrans/TRADE/v2/client/orders/actions/limit/{orderId} | Изменение лимитной заявки
[**command_api_v2clientordersactionsmarket**](DefaultApi.md#command_api_v2clientordersactionsmarket) | **POST** /commandapi/warptrans/TRADE/v2/client/orders/actions/market | Создание рыночной заявки
[**command_api_v2clientordersactionsmarketput**](DefaultApi.md#command_api_v2clientordersactionsmarketput) | **PUT** /commandapi/warptrans/TRADE/v2/client/orders/actions/market/{orderId} | Изменение рыночной заявки
[**command_api_v2clientordersdelete**](DefaultApi.md#command_api_v2clientordersdelete) | **DELETE** /commandapi/warptrans/TRADE/v2/client/orders/{orderId} | Снятие заявки
[**dev_get_all_orders**](DefaultApi.md#dev_get_all_orders) | **GET** /md/v2/clients/{exchange}/{portfolio}/orders | Получение информации о всех заявках
[**dev_get_all_positions**](DefaultApi.md#dev_get_all_positions) | **GET** /md/v2/Clients/{exchange}/{portfolio}/positions | Получение информации о позициях
[**dev_get_all_stop_orders**](DefaultApi.md#dev_get_all_stop_orders) | **GET** /md/v2/clients/{exchange}/{portfolio}/stoporders | Получение информации о стоп-заявках
[**dev_get_all_trades**](DefaultApi.md#dev_get_all_trades) | **GET** /md/v2/Clients/{exchange}/{portfolio}/trades | Получение информации о сделках
[**dev_get_one_order**](DefaultApi.md#dev_get_one_order) | **GET** /md/v2/clients/{exchange}/{portfolio}/orders/{orderId} | Получение информации о выбранной заявке
[**dev_get_one_position**](DefaultApi.md#dev_get_one_position) | **GET** /md/v2/Clients/{exchange}/{portfolio}/positions/{symbol} | Получение информации о позициях выбранного инструмента
[**dev_get_one_stop_order**](DefaultApi.md#dev_get_one_stop_order) | **GET** /md/v2/clients/{exchange}/{portfolio}/stoporders/{orderId} | Получение информации о выбранной стоп-заявке
[**dev_get_ticker_trades**](DefaultApi.md#dev_get_ticker_trades) | **GET** /md/v2/Clients/{exchange}/{portfolio}/{ticker}/trades | Получение информации о сделках по выбранному инструменту
[**dev_history**](DefaultApi.md#dev_history) | **GET** /md/v2/history | Запрос истории для выбранных биржи и инструмента
[**dev_orderbook_exchang_seccode**](DefaultApi.md#dev_orderbook_exchang_seccode) | **GET** /md/v2/orderbooks/{exchange}/{seccode} | Получение информации о биржевом стакане
[**dev_quotes**](DefaultApi.md#dev_quotes) | **GET** /md/v2/Securities/{symbols}/quotes | Получение информации о котировках для выбранных инструментов
[**dev_securities_futures**](DefaultApi.md#dev_securities_futures) | **GET** /md/v2/Securities/{exchange}/{symbol}/actualFuturesQuote | Получение котировки по ближайшему фьючерсу (код)
[**dev_securities_search**](DefaultApi.md#dev_securities_search) | **GET** /md/v2/Securities | Получение информации о торговых инструментах
[**dev_securities_search_all_trades**](DefaultApi.md#dev_securities_search_all_trades) | **GET** /md/v2/Securities/{exchange}/{symbol}/alltrades | Получение информации о всех сделках по ценным бумагам за сегодня
[**dev_securities_search_exchange**](DefaultApi.md#dev_securities_search_exchange) | **GET** /md/v2/Securities/{exchange} | Получение информации о торговых инструментах на выбранной бирже
[**dev_securities_search_exchange_code**](DefaultApi.md#dev_securities_search_exchange_code) | **GET** /md/v2/Securities/{exchange}/{symbol} | Получение информации о выбранном финансовом инструменте
[**dev_user_portfolio**](DefaultApi.md#dev_user_portfolio) | **GET** /client/v1.0/users/{username}/portfolios | Получение списка серверов портфелей
[**exchange_portfolio_money**](DefaultApi.md#exchange_portfolio_money) | **GET** /md/v2/clients/legacy/{exchange}/{portfolio}/money | Получение информации по деньгам для выбранного портфеля
[**exchange_portfolio_summary**](DefaultApi.md#exchange_portfolio_summary) | **GET** /md/v2/clients/{exchange}/{portfolio}/summary | Получение информации о портфеле
[**fortsrisk**](DefaultApi.md#fortsrisk) | **GET** /md/v2/Clients/{exchange}/{portfolio}/fortsrisk | Получение информации о рисках на срочном рынке
[**local_time**](DefaultApi.md#local_time) | **GET** /md/v2/time | Запрос текущего UTC времени в формате Unix
[**risk**](DefaultApi.md#risk) | **GET** /md/v2/Clients/{exchange}/{portfolio}/risk | Получение информации о рисках
[**v2clientordersactionsorder_id**](DefaultApi.md#v2clientordersactionsorder_id) | **DELETE** /warptrans/{tradeServerCode}/v2/client/orders/{orderId} | Снятие стоп-заявки
[**v2clientordersactionsstop_loss**](DefaultApi.md#v2clientordersactionsstop_loss) | **POST** /warptrans/{tradeServerCode}/v2/client/orders/actions/stopLoss | Создание стоп-лосс заявки
[**v2clientordersactionsstop_loss_limit**](DefaultApi.md#v2clientordersactionsstop_loss_limit) | **POST** /warptrans/{tradeServerCode}/v2/client/orders/actions/stopLossLimit | Создание стоп-лосс лимит заявки
[**v2clientordersactionsstop_loss_limitorder_id**](DefaultApi.md#v2clientordersactionsstop_loss_limitorder_id) | **PUT** /warptrans/{tradeServerCode}/v2/client/orders/actions/stopLossLimit/{orderId} | Изменение стоп-лосс лимит заявки
[**v2clientordersactionsstop_lossorder_id**](DefaultApi.md#v2clientordersactionsstop_lossorder_id) | **PUT** /warptrans/{tradeServerCode}/v2/client/orders/actions/stopLoss/{orderId} | Изменение стоп-лосс заявки
[**v2clientordersactionstake_profit**](DefaultApi.md#v2clientordersactionstake_profit) | **POST** /warptrans/{tradeServerCode}/v2/client/orders/actions/takeProfit | Создание стоп-заявки
[**v2clientordersactionstake_profit_limit**](DefaultApi.md#v2clientordersactionstake_profit_limit) | **POST** /warptrans/{tradeServerCode}/v2/client/orders/actions/takeProfitLimit | Создание стоп-лимит заявки
[**v2clientordersactionstake_profit_limitorder_id**](DefaultApi.md#v2clientordersactionstake_profit_limitorder_id) | **PUT** /warptrans/{tradeServerCode}/v2/client/orders/actions/takeProfitLimit/{orderId} | Изменение стоп-лимит заявки
[**v2clientordersactionstake_profitorder_id**](DefaultApi.md#v2clientordersactionstake_profitorder_id) | **PUT** /warptrans/{tradeServerCode}/v2/client/orders/actions/takeProfit/{orderId} | Изменение стоп-заявки

# **command_api_v2clientordersactionslimit**
> OrdersActionsLimitMarketCommandAPI command_api_v2clientordersactionslimit(body, x_alor_reqid)

Создание лимитной заявки

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsLimitTV() # BodyrequestOrdersActionsLimitTV | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Через точку с запятой портфель и уникальный идентификатор запроса ``portfolio;uid``. В качестве идентификатора запроса требуется уникальная случайная строка. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на предыдущий запрос с таким значением идентификатора.

try:
    # Создание лимитной заявки
    api_response = api_instance.command_api_v2clientordersactionslimit(body, x_alor_reqid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->command_api_v2clientordersactionslimit: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsLimitTV**](BodyrequestOrdersActionsLimitTV.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Через точку с запятой портфель и уникальный идентификатор запроса &#x60;&#x60;portfolio;uid&#x60;&#x60;. В качестве идентификатора запроса требуется уникальная случайная строка. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на предыдущий запрос с таким значением идентификатора. | 

### Return type

[**OrdersActionsLimitMarketCommandAPI**](OrdersActionsLimitMarketCommandAPI.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **command_api_v2clientordersactionslimitput**
> OrdersActionsLimitMarket command_api_v2clientordersactionslimitput(body, x_alor_reqid, order_id)

Изменение лимитной заявки

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsLimitTVput() # BodyrequestOrdersActionsLimitTVput | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Через точку с запятой портфолио и уникальный идентификатор запроса ``portfolio;uid``. В качестве идентификатора запроса требуется уникальная случайная строка из цифр. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
order_id = 'order_id_example' # str | Идентификатор заявки

try:
    # Изменение лимитной заявки
    api_response = api_instance.command_api_v2clientordersactionslimitput(body, x_alor_reqid, order_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->command_api_v2clientordersactionslimitput: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsLimitTVput**](BodyrequestOrdersActionsLimitTVput.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Через точку с запятой портфолио и уникальный идентификатор запроса &#x60;&#x60;portfolio;uid&#x60;&#x60;. В качестве идентификатора запроса требуется уникальная случайная строка из цифр. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **order_id** | **str**| Идентификатор заявки | 

### Return type

[**OrdersActionsLimitMarket**](OrdersActionsLimitMarket.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **command_api_v2clientordersactionsmarket**
> OrdersActionsLimitMarketCommandAPI command_api_v2clientordersactionsmarket(body, x_alor_reqid)

Создание рыночной заявки

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsMarketTV() # BodyrequestOrdersActionsMarketTV | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Через точку с запятой портфель и уникальный идентификатор запроса ``portfolio;uid``. В качестве идентификатора запроса требуется уникальная случайная строка. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на предыдущий запрос с таким значением идентификатора.

try:
    # Создание рыночной заявки
    api_response = api_instance.command_api_v2clientordersactionsmarket(body, x_alor_reqid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->command_api_v2clientordersactionsmarket: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsMarketTV**](BodyrequestOrdersActionsMarketTV.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Через точку с запятой портфель и уникальный идентификатор запроса &#x60;&#x60;portfolio;uid&#x60;&#x60;. В качестве идентификатора запроса требуется уникальная случайная строка. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на предыдущий запрос с таким значением идентификатора. | 

### Return type

[**OrdersActionsLimitMarketCommandAPI**](OrdersActionsLimitMarketCommandAPI.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **command_api_v2clientordersactionsmarketput**
> OrdersActionsLimitMarket command_api_v2clientordersactionsmarketput(body, x_alor_reqid, order_id)

Изменение рыночной заявки

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsMarketTVput() # BodyrequestOrdersActionsMarketTVput | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Через точку с запятой портфолио и уникальный идентификатор запроса ``portfolio;uid``. В качестве идентификатора запроса требуется уникальная случайная строка из цифр. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
order_id = 'order_id_example' # str | Идентификатор заявки

try:
    # Изменение рыночной заявки
    api_response = api_instance.command_api_v2clientordersactionsmarketput(body, x_alor_reqid, order_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->command_api_v2clientordersactionsmarketput: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsMarketTVput**](BodyrequestOrdersActionsMarketTVput.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Через точку с запятой портфолио и уникальный идентификатор запроса &#x60;&#x60;portfolio;uid&#x60;&#x60;. В качестве идентификатора запроса требуется уникальная случайная строка из цифр. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **order_id** | **str**| Идентификатор заявки | 

### Return type

[**OrdersActionsLimitMarket**](OrdersActionsLimitMarket.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **command_api_v2clientordersdelete**
> OrdersActionsDeleteOrderIdCommandAPI command_api_v2clientordersdelete(order_id, account, portfolio, exchange, stop, format)

Снятие заявки

Снятие заявки с указанным идентификатором

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
order_id = 'order_id_example' # str | Идентификатор заявки
account = 'account_example' # str | Идентификатор аккаунта пользователя
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
exchange = 'exchange_example' # str | Биржа
stop = 'stop_example' # str | Является стоп-заявкой?
format = 'format_example' # str | Формат возвращаемого сервером JSON

try:
    # Снятие заявки
    api_response = api_instance.command_api_v2clientordersdelete(order_id, account, portfolio, exchange, stop, format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->command_api_v2clientordersdelete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_id** | **str**| Идентификатор заявки | 
 **account** | **str**| Идентификатор аккаунта пользователя | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **exchange** | **str**| Биржа | 
 **stop** | **str**| Является стоп-заявкой? | 
 **format** | **str**| Формат возвращаемого сервером JSON | 

### Return type

[**OrdersActionsDeleteOrderIdCommandAPI**](OrdersActionsDeleteOrderIdCommandAPI.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_get_all_orders**
> Orders dev_get_all_orders(exchange, portfolio, format=format)

Получение информации о всех заявках

Запрос информации о всех заявках

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о всех заявках
    api_response = api_instance.dev_get_all_orders(exchange, portfolio, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_get_all_orders: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Orders**](Orders.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_get_all_positions**
> Positions dev_get_all_positions(exchange, portfolio, format=format, without_currency=without_currency)

Получение информации о позициях

Запрос информации о позициях

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)
without_currency = true # bool | Исключить из ответа все денежные инструменты, по умолчанию false (optional)

try:
    # Получение информации о позициях
    api_response = api_instance.dev_get_all_positions(exchange, portfolio, format=format, without_currency=without_currency)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_get_all_positions: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 
 **without_currency** | **bool**| Исключить из ответа все денежные инструменты, по умолчанию false | [optional] 

### Return type

[**Positions**](Positions.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_get_all_stop_orders**
> Stoporders dev_get_all_stop_orders(exchange, portfolio, format=format)

Получение информации о стоп-заявках

Запрос информации о всех стоп-заявках

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о стоп-заявках
    api_response = api_instance.dev_get_all_stop_orders(exchange, portfolio, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_get_all_stop_orders: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Stoporders**](Stoporders.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_get_all_trades**
> Trades dev_get_all_trades(exchange, portfolio, format=format)

Получение информации о сделках

Запрос информации о сделках

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о сделках
    api_response = api_instance.dev_get_all_trades(exchange, portfolio, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_get_all_trades: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Trades**](Trades.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_get_one_order**
> Order dev_get_one_order(exchange, portfolio, order_id, format=format)

Получение информации о выбранной заявке

Запрос информации о выбранной заявке

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
order_id = 56 # int | Идентификатор заявки
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о выбранной заявке
    api_response = api_instance.dev_get_one_order(exchange, portfolio, order_id, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_get_one_order: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **order_id** | **int**| Идентификатор заявки | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Order**](Order.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_get_one_position**
> Position dev_get_one_position(exchange, portfolio, symbol, format=format)

Получение информации о позициях выбранного инструмента

Запрос информации о позициях выбранного инструмента

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
symbol = 'symbol_example' # str | Тикер (Код финансового инструмента)
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о позициях выбранного инструмента
    api_response = api_instance.dev_get_one_position(exchange, portfolio, symbol, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_get_one_position: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **symbol** | **str**| Тикер (Код финансового инструмента) | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Position**](Position.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_get_one_stop_order**
> Stoporder dev_get_one_stop_order(exchange, portfolio, order_id, format=format)

Получение информации о выбранной стоп-заявке

Запрос информации о выбранной стоп-заявке

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
order_id = 56 # int | Идентификатор стоп-заявки
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о выбранной стоп-заявке
    api_response = api_instance.dev_get_one_stop_order(exchange, portfolio, order_id, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_get_one_stop_order: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **order_id** | **int**| Идентификатор стоп-заявки | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Stoporder**](Stoporder.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_get_ticker_trades**
> Trades dev_get_ticker_trades(exchange, portfolio, ticker, format=format)

Получение информации о сделках по выбранному инструменту

Запрос информации о сделках по выбранному инструменту

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
ticker = 'ticker_example' # str | Тикер (Код финансового инструмента)
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о сделках по выбранному инструменту
    api_response = api_instance.dev_get_ticker_trades(exchange, portfolio, ticker, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_get_ticker_trades: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **ticker** | **str**| Тикер (Код финансового инструмента) | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Trades**](Trades.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_history**
> History dev_history(symbol, exchange, tf, _from, to, format=format)

Запрос истории для выбранных биржи и инструмента

Запрос истории рынка для выбранных биржи и финансового инструмента. Данные имеют задержку в 15 минут, если запрос не авторизован. Для авторизованных клиентов задержка не применяется.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
symbol = 'symbol_example' # str | Тикер (Код финансового инструмента)
exchange = 'exchange_example' # str | Биржа
tf = 'tf_example' # str | Длительность таймфрейма в секундах или код (\"D\" - дни, \"W\" - недели, \"M\" - месяцы, \"Y\" - годы)
_from = 56 # int | Начало отрезка времени (UTC) в формате Unix Time Seconds
to = 56 # int | Конец отрезка времени (UTC) в формате Unix Time Seconds
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Запрос истории для выбранных биржи и инструмента
    api_response = api_instance.dev_history(symbol, exchange, tf, _from, to, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_history: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **symbol** | **str**| Тикер (Код финансового инструмента) | 
 **exchange** | **str**| Биржа | 
 **tf** | **str**| Длительность таймфрейма в секундах или код (\&quot;D\&quot; - дни, \&quot;W\&quot; - недели, \&quot;M\&quot; - месяцы, \&quot;Y\&quot; - годы) | 
 **_from** | **int**| Начало отрезка времени (UTC) в формате Unix Time Seconds | 
 **to** | **int**| Конец отрезка времени (UTC) в формате Unix Time Seconds | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**History**](History.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_orderbook_exchang_seccode**
> Orderbook dev_orderbook_exchang_seccode(exchange, seccode, depth=depth, format=format)

Получение информации о биржевом стакане

Запрос биржевого стакана

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
seccode = 'seccode_example' # str | Инструмент
depth = 56 # int | Глубина стакана. Стандартное и максимальное значение - 20 (20х20). (optional)
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о биржевом стакане
    api_response = api_instance.dev_orderbook_exchang_seccode(exchange, seccode, depth=depth, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_orderbook_exchang_seccode: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **seccode** | **str**| Инструмент | 
 **depth** | **int**| Глубина стакана. Стандартное и максимальное значение - 20 (20х20). | [optional] 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Orderbook**](Orderbook.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_quotes**
> Symbols dev_quotes(symbols, format=format)

Получение информации о котировках для выбранных инструментов

Запрос информации о котировках для выбранных инструментов и бирж

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
symbols = 'symbols_example' # str | Принимает несколько пар биржа-тикер. Пары отделены запятыми. Биржа и тикер разделены двоеточием
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о котировках для выбранных инструментов
    api_response = api_instance.dev_quotes(symbols, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_quotes: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **symbols** | **str**| Принимает несколько пар биржа-тикер. Пары отделены запятыми. Биржа и тикер разделены двоеточием | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Symbols**](Symbols.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_securities_futures**
> SymbolFutures dev_securities_futures(exchange, symbol, format=format)

Получение котировки по ближайшему фьючерсу (код)

Запрос котировки по ближайшему фьючерсу (только по коду, без даты)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
symbol = 'symbol_example' # str | Тикер (Код финансового инструмента)
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение котировки по ближайшему фьючерсу (код)
    api_response = api_instance.dev_securities_futures(exchange, symbol, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_securities_futures: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **symbol** | **str**| Тикер (Код финансового инструмента) | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**SymbolFutures**](SymbolFutures.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_securities_search**
> Securities dev_securities_search(query, limit=limit, sector=sector, cficode=cficode, exchange=exchange, format=format)

Получение информации о торговых инструментах

Запрос информации о торговых инструментах

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
query = 'query_example' # str | Тикер (Код финансового инструмента)
limit = 56 # int | Ограничение на количество выдаваемых результатов поиска (optional)
sector = 'sector_example' # str | Рынок на бирже (optional)
cficode = 'cficode_example' # str | Код финансового инструмента по стандарту ISO 10962 (optional)
exchange = 'exchange_example' # str | Биржа (optional)
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о торговых инструментах
    api_response = api_instance.dev_securities_search(query, limit=limit, sector=sector, cficode=cficode, exchange=exchange, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_securities_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **str**| Тикер (Код финансового инструмента) | 
 **limit** | **int**| Ограничение на количество выдаваемых результатов поиска | [optional] 
 **sector** | **str**| Рынок на бирже | [optional] 
 **cficode** | **str**| Код финансового инструмента по стандарту ISO 10962 | [optional] 
 **exchange** | **str**| Биржа | [optional] 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Securities**](Securities.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_securities_search_all_trades**
> Alltrades dev_securities_search_all_trades(exchange, symbol, format=format, _from=_from, to=to)

Получение информации о всех сделках по ценным бумагам за сегодня

Запросить данные о всех сделках (лента) по ценным бумагам за сегодняшний день

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
symbol = 'symbol_example' # str | Тикер (Код финансового инструмента)
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)
_from = 56 # int | Начало отрезка времени (UTC) для фильтра результатов в формате Unix Time Seconds (optional)
to = 56 # int | Конец отрезка времени (UTC) для фильтра результатов в формате Unix Time Seconds (optional)

try:
    # Получение информации о всех сделках по ценным бумагам за сегодня
    api_response = api_instance.dev_securities_search_all_trades(exchange, symbol, format=format, _from=_from, to=to)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_securities_search_all_trades: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **symbol** | **str**| Тикер (Код финансового инструмента) | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 
 **_from** | **int**| Начало отрезка времени (UTC) для фильтра результатов в формате Unix Time Seconds | [optional] 
 **to** | **int**| Конец отрезка времени (UTC) для фильтра результатов в формате Unix Time Seconds | [optional] 

### Return type

[**Alltrades**](Alltrades.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_securities_search_exchange**
> Securities dev_securities_search_exchange(exchange, format=format)

Получение информации о торговых инструментах на выбранной бирже

Запрос информации об инструментах на выбранной бирже

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о торговых инструментах на выбранной бирже
    api_response = api_instance.dev_securities_search_exchange(exchange, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_securities_search_exchange: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Securities**](Securities.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_securities_search_exchange_code**
> Security dev_securities_search_exchange_code(exchange, symbol, format=format)

Получение информации о выбранном финансовом инструменте

Запрос информации о выбранном финансовом инструменте на бирже

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
symbol = 'symbol_example' # str | Тикер (Код финансового инструмента)
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о выбранном финансовом инструменте
    api_response = api_instance.dev_securities_search_exchange_code(exchange, symbol, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_securities_search_exchange_code: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **symbol** | **str**| Тикер (Код финансового инструмента) | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Security**](Security.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **dev_user_portfolio**
> ServersInfo dev_user_portfolio(username)

Получение списка серверов портфелей

Получение списка серверов по секциям «Валютный рынок», «Срочный рынок», «Фондовый рынок». В ответе в поле tradeServerCode содержится значение которое надо использовать

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
username = 'username_example' # str | Имя пользователя

try:
    # Получение списка серверов портфелей
    api_response = api_instance.dev_user_portfolio(username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->dev_user_portfolio: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| Имя пользователя | 

### Return type

[**ServersInfo**](ServersInfo.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **exchange_portfolio_money**
> Money exchange_portfolio_money(exchange, portfolio, format=format)

Получение информации по деньгам для выбранного портфеля

Запрос информации о позиции по деньгам. Вызов существует для обратной совместимости с API v1, предпочтительно использовать другие вызовы (/summary, /risk, /positions)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации по деньгам для выбранного портфеля
    api_response = api_instance.exchange_portfolio_money(exchange, portfolio, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->exchange_portfolio_money: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Money**](Money.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **exchange_portfolio_summary**
> Summary exchange_portfolio_summary(exchange, portfolio, format=format)

Получение информации о портфеле

Запрос сводной информации о портфеле

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о портфеле
    api_response = api_instance.exchange_portfolio_summary(exchange, portfolio, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->exchange_portfolio_summary: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Summary**](Summary.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **fortsrisk**
> Fortsrisk fortsrisk(exchange, portfolio, format=format)

Получение информации о рисках на срочном рынке

Запрос информации о рисках на срочном рынке для выбранного портфеля

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о рисках на срочном рынке
    api_response = api_instance.fortsrisk(exchange, portfolio, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->fortsrisk: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Fortsrisk**](Fortsrisk.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **local_time**
> Time local_time()

Запрос текущего UTC времени в формате Unix

Запрос текущего UTC времени в формате Unix Time Seconds. Если этот запрос выполнен без авторизации, то будет возвращено время, которое было 15 минут назад.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))

try:
    # Запрос текущего UTC времени в формате Unix
    api_response = api_instance.local_time()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->local_time: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Time**](Time.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **risk**
> Risk risk(exchange, portfolio, format=format)

Получение информации о рисках

Запрос информации о рисках

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
exchange = 'exchange_example' # str | Биржа
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
format = 'format_example' # str | Формат возвращаемого сервером JSON (optional)

try:
    # Получение информации о рисках
    api_response = api_instance.risk(exchange, portfolio, format=format)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->risk: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **exchange** | **str**| Биржа | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **format** | **str**| Формат возвращаемого сервером JSON | [optional] 

### Return type

[**Risk**](Risk.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v2clientordersactionsorder_id**
> OrdersActionsDeleteOrderId v2clientordersactionsorder_id(trade_server_code, order_id, portfolio, stop, x_alor_reqid)

Снятие стоп-заявки

Снятие стоп-заявки с указанным идентификатором

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
trade_server_code = 'trade_server_code_example' # str | Код торгового сервера
order_id = 56 # int | Идентификатор заявки
portfolio = 'portfolio_example' # str | Идентификатор клиентского портфеля
stop = true # bool | Является стоп-заявкой?
x_alor_reqid = 'x_alor_reqid_example' # str | Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора

try:
    # Снятие стоп-заявки
    api_response = api_instance.v2clientordersactionsorder_id(trade_server_code, order_id, portfolio, stop, x_alor_reqid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->v2clientordersactionsorder_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trade_server_code** | **str**| Код торгового сервера | 
 **order_id** | **int**| Идентификатор заявки | 
 **portfolio** | **str**| Идентификатор клиентского портфеля | 
 **stop** | **bool**| Является стоп-заявкой? | 
 **x_alor_reqid** | **str**| Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 

### Return type

[**OrdersActionsDeleteOrderId**](OrdersActionsDeleteOrderId.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, string

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v2clientordersactionsstop_loss**
> OrdersActionsStopProfitLoss v2clientordersactionsstop_loss(body, x_alor_reqid, trade_server_code)

Создание стоп-лосс заявки

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsStop() # BodyrequestOrdersActionsStop | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
trade_server_code = 'trade_server_code_example' # str | Код торгового сервера

try:
    # Создание стоп-лосс заявки
    api_response = api_instance.v2clientordersactionsstop_loss(body, x_alor_reqid, trade_server_code)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->v2clientordersactionsstop_loss: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsStop**](BodyrequestOrdersActionsStop.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **trade_server_code** | **str**| Код торгового сервера | 

### Return type

[**OrdersActionsStopProfitLoss**](OrdersActionsStopProfitLoss.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v2clientordersactionsstop_loss_limit**
> OrdersActionsStopProfitLoss v2clientordersactionsstop_loss_limit(body, x_alor_reqid, trade_server_code)

Создание стоп-лосс лимит заявки

Создание стоп-лосс лимит заявки

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsStoplimit() # BodyrequestOrdersActionsStoplimit | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
trade_server_code = 'trade_server_code_example' # str | Код торгового сервера

try:
    # Создание стоп-лосс лимит заявки
    api_response = api_instance.v2clientordersactionsstop_loss_limit(body, x_alor_reqid, trade_server_code)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->v2clientordersactionsstop_loss_limit: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsStoplimit**](BodyrequestOrdersActionsStoplimit.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **trade_server_code** | **str**| Код торгового сервера | 

### Return type

[**OrdersActionsStopProfitLoss**](OrdersActionsStopProfitLoss.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v2clientordersactionsstop_loss_limitorder_id**
> OrdersActionsStopProfitLoss v2clientordersactionsstop_loss_limitorder_id(body, x_alor_reqid, trade_server_code, order_id)

Изменение стоп-лосс лимит заявки

Изменение стоп-лосс лимит заявки с указанным номером

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsStoplimit() # BodyrequestOrdersActionsStoplimit | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
trade_server_code = 'trade_server_code_example' # str | Код торгового сервера
order_id = 56 # int | Идентификатор заявки

try:
    # Изменение стоп-лосс лимит заявки
    api_response = api_instance.v2clientordersactionsstop_loss_limitorder_id(body, x_alor_reqid, trade_server_code, order_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->v2clientordersactionsstop_loss_limitorder_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsStoplimit**](BodyrequestOrdersActionsStoplimit.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **trade_server_code** | **str**| Код торгового сервера | 
 **order_id** | **int**| Идентификатор заявки | 

### Return type

[**OrdersActionsStopProfitLoss**](OrdersActionsStopProfitLoss.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, string

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v2clientordersactionsstop_lossorder_id**
> OrdersActionsStopProfitLoss v2clientordersactionsstop_lossorder_id(body, x_alor_reqid, trade_server_code, order_id)

Изменение стоп-лосс заявки

Изменение стоп-лосс заявки с указанным номером

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsStop() # BodyrequestOrdersActionsStop | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
trade_server_code = 'trade_server_code_example' # str | Код торгового сервера
order_id = 56 # int | Идентификатор заявки

try:
    # Изменение стоп-лосс заявки
    api_response = api_instance.v2clientordersactionsstop_lossorder_id(body, x_alor_reqid, trade_server_code, order_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->v2clientordersactionsstop_lossorder_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsStop**](BodyrequestOrdersActionsStop.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **trade_server_code** | **str**| Код торгового сервера | 
 **order_id** | **int**| Идентификатор заявки | 

### Return type

[**OrdersActionsStopProfitLoss**](OrdersActionsStopProfitLoss.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, string

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v2clientordersactionstake_profit**
> OrdersActionsStopProfitLoss v2clientordersactionstake_profit(body, x_alor_reqid, trade_server_code)

Создание стоп-заявки

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsStop() # BodyrequestOrdersActionsStop | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
trade_server_code = 'trade_server_code_example' # str | Код торгового сервера

try:
    # Создание стоп-заявки
    api_response = api_instance.v2clientordersactionstake_profit(body, x_alor_reqid, trade_server_code)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->v2clientordersactionstake_profit: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsStop**](BodyrequestOrdersActionsStop.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **trade_server_code** | **str**| Код торгового сервера | 

### Return type

[**OrdersActionsStopProfitLoss**](OrdersActionsStopProfitLoss.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v2clientordersactionstake_profit_limit**
> OrdersActionsStopProfitLoss v2clientordersactionstake_profit_limit(body, x_alor_reqid, trade_server_code)

Создание стоп-лимит заявки

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsStoplimit() # BodyrequestOrdersActionsStoplimit | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
trade_server_code = 'trade_server_code_example' # str | Код торгового сервера

try:
    # Создание стоп-лимит заявки
    api_response = api_instance.v2clientordersactionstake_profit_limit(body, x_alor_reqid, trade_server_code)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->v2clientordersactionstake_profit_limit: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsStoplimit**](BodyrequestOrdersActionsStoplimit.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **trade_server_code** | **str**| Код торгового сервера | 

### Return type

[**OrdersActionsStopProfitLoss**](OrdersActionsStopProfitLoss.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v2clientordersactionstake_profit_limitorder_id**
> OrdersActionsStopProfitLoss v2clientordersactionstake_profit_limitorder_id(body, x_alor_reqid, trade_server_code, order_id)

Изменение стоп-лимит заявки

Изменение стоп-лимит заявки с указанным номером

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsStoplimit() # BodyrequestOrdersActionsStoplimit | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
trade_server_code = 'trade_server_code_example' # str | Код торгового сервера
order_id = 56 # int | Идентификатор заявки

try:
    # Изменение стоп-лимит заявки
    api_response = api_instance.v2clientordersactionstake_profit_limitorder_id(body, x_alor_reqid, trade_server_code, order_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->v2clientordersactionstake_profit_limitorder_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsStoplimit**](BodyrequestOrdersActionsStoplimit.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **trade_server_code** | **str**| Код торгового сервера | 
 **order_id** | **int**| Идентификатор заявки | 

### Return type

[**OrdersActionsStopProfitLoss**](OrdersActionsStopProfitLoss.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, string

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v2clientordersactionstake_profitorder_id**
> OrdersActionsStopProfitLoss v2clientordersactionstake_profitorder_id(body, x_alor_reqid, trade_server_code, order_id)

Изменение стоп-заявки

Изменение стоп-заявки с указанным номером

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.DefaultApi(swagger_client.ApiClient(configuration))
body = swagger_client.BodyrequestOrdersActionsStop() # BodyrequestOrdersActionsStop | Тело заявки
x_alor_reqid = 'x_alor_reqid_example' # str | Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора
trade_server_code = 'trade_server_code_example' # str | Код торгового сервера
order_id = 56 # int | Идентификатор заявки

try:
    # Изменение стоп-заявки
    api_response = api_instance.v2clientordersactionstake_profitorder_id(body, x_alor_reqid, trade_server_code, order_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->v2clientordersactionstake_profitorder_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BodyrequestOrdersActionsStop**](BodyrequestOrdersActionsStop.md)| Тело заявки | 
 **x_alor_reqid** | **str**| Требуется уникальная случайная строка в качестве идентификатора запроса. Если уже приходил запрос с таким идентификатором, то заявка не будет исполнена повторно, а в качестве ответа будет возвращена копия ответа на первый запрос с таким значением идентификатора | 
 **trade_server_code** | **str**| Код торгового сервера | 
 **order_id** | **int**| Идентификатор заявки | 

### Return type

[**OrdersActionsStopProfitLoss**](OrdersActionsStopProfitLoss.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, string

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

