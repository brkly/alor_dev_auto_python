# HistoryObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**time** | **int** | Время (UTC) (Unix time seconds) | [optional] 
**close** | **float** | Цена при закрытии | [optional] 
**open** | **float** | Цена при открытии | [optional] 
**high** | **float** | Максимальная цена | [optional] 
**low** | **float** | Миниимальная цена | [optional] 
**volume** | **int** | Объём | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

