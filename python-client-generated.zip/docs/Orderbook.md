# Orderbook

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**snapshot** | **bool** | Deprecated. Устаревшее поле, будет удалено в будущих обновлениях. | [optional] 
**bids** | [**list[OrderbookBid]**](OrderbookBid.md) | Биды | [optional] 
**asks** | [**list[OrderbookAsk]**](OrderbookAsk.md) | Аски | [optional] 
**timestamp** | **float** | Deprecated. Устаревшее поле, будет удалено в будущих обновлениях. Вместо этого поля используйте поле \&quot;ms_timestamp\&quot;. | [optional] 
**ms_timestamp** | **float** | Время(UTC) в формате Unix Time Milliseconds | [optional] 
**existing** | **bool** | True - для данных из \&quot;снепшота\&quot;, то есть из истории. False - для новых событий | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

