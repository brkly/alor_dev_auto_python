# Fortsrisk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**portfolio** | **str** | Идентификатор клиентского портфеля | [optional] 
**money_free** | **float** | Свободные средства. Сумма рублей и залогов, дисконтированных в рубли, доступная для открытия позиций. (MoneyFree &#x3D; MoneyAmount + VmInterCl – MoneyBlocked – VmReserve – Fee) | [optional] 
**money_blocked** | **float** | Средства, заблокированные под ГО | [optional] 
**balance_money** | **float** | Сальдо денежных торговых переводов за текущую сессию | [optional] 
**fee** | **float** | Списанный сбор | [optional] 
**money_old** | **float** | Общее количество рублей и дисконтированных в рубли залогов на начало сессии | [optional] 
**money_amount** | **float** | Общее количество рублей и дисконтированных в рубли залогов | [optional] 
**money_pledge_amount** | **float** | Сумма залогов, дисконтированных в рубли | [optional] 
**vm_inter_cl** | **float** | Вариационная маржа, списанная или полученная в пром. клиринг | [optional] 
**vm_current_positions** | **float** | Сагрегированная вармаржа по текущим позициям | [optional] 
**var_margin** | **float** | VmCurrentPositions + VmInterCl | [optional] 
**is_limits_set** | **bool** | Наличие установленных денежного и залогового лимитов | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

