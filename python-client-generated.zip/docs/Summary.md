# Summary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**buying_power_at_morning** | **float** | Покупательская способность на утро | [optional] 
**buying_power** | **float** | Покупательская способность | [optional] 
**profit** | **float** | Прибыль за сегодня | [optional] 
**profit_rate** | **float** | Норма прибыли, % | [optional] 
**portfolio_evaluation** | **float** | Ликвидный портфель | [optional] 
**portfolio_liquidation_value** | **float** | Оценка портфеля | [optional] 
**initial_margin** | **float** | Маржа | [optional] 
**risk_before_force_position_closing** | **float** | Риск до закрытия | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

