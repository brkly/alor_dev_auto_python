# Order

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Уникальный идентификатор заявки | [optional] 
**symbol** | **str** | Тикер (Код финансового инструмента) | [optional] 
**broker_symbol** | **str** | Пара биржа-Тикер | [optional] 
**exchange** | **str** | Биржа | [optional] 
**type** | **str** | Тип заявки. Лимитная либо рыночная. | [optional] 
**side** | **str** | Направление сделки. Купля либо продажа. | [optional] 
**status** | **str** | Статус исполнения. На исполнении, исполнена, отменена, отклонена. | [optional] 
**trans_time** | **str** | Время выставления (UTC) | [optional] 
**end_time** | **str** | Время завершения (UTC) | [optional] 
**qty_units** | **float** | Количество (штуки) | [optional] 
**qty_batch** | **float** | Количество (лоты) | [optional] 
**qty** | **float** | Количество (лоты) | [optional] 
**filled_qty_units** | **float** | Количество исполненных (штуки) | [optional] 
**filled_qty_batch** | **float** | Количество исполненных (лоты) | [optional] 
**filled** | **float** | Количество исполненных (лоты) | [optional] 
**price** | **float** | Цена | [optional] 
**existing** | **bool** | True - для данных из \&quot;снепшота\&quot;, то есть из истории. False - для новых событий | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

