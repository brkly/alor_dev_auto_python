# BodyrequestOrdersActionsStoplimit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | **int** | Количество | [optional] 
**side** | **str** | Направление сделки. Купля либо продажа. | [optional] 
**trigger_price** | **int** | Стоп-цена | [optional] 
**price** | **int** | Цена | [optional] 
**instrument** | [**BodyrequestOrdersActionsStoplimitInstrument**](BodyrequestOrdersActionsStoplimitInstrument.md) |  | [optional] 
**user** | [**BodyrequestOrdersActionsStoplimitUser**](BodyrequestOrdersActionsStoplimitUser.md) |  | [optional] 
**order_end_unix_time** | **int** | Время (UTC) завершения сделки в формате Unix Time seconds | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

