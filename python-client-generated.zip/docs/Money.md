# Money

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cash** | **float** | Количество средств | [optional] 
**used** | **float** | Количество использованных | [optional] 
**open** | **float** | Средства на момент открытия | [optional] 
**profit** | **float** | Прибыль | [optional] 
**profit_rate** | **float** | Прибыль в процентах | [optional] 
**comission** | **float** | Комиссия | [optional] 
**changes** | **float** | Изменения | [optional] 
**portfolio** | **float** | Идентификатор клиентского портфеля | [optional] 
**free** | **float** | Свободные средства | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

