# BodyrequestOrdersActionsLimitTV

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**side** | **str** | Направление сделки. Купля либо продажа. | [optional] 
**type** | **str** | Тип заявки | [optional] 
**quantity** | **int** | Количество (лоты) | [optional] 
**price** | **float** | Цена | [optional] 
**instrument** | [**BodyrequestOrdersActionsLimitTVputInstrument**](BodyrequestOrdersActionsLimitTVputInstrument.md) |  | [optional] 
**user** | [**BodyrequestOrdersActionsLimitTVputUser**](BodyrequestOrdersActionsLimitTVputUser.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

