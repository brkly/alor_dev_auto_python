# Trade

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Уникальный идентификатор сделки | [optional] 
**orderno** | **str** | Идентификатор заявки | [optional] 
**symbol** | **str** | Тикер (Код финансового инструмента). \&quot;[N/A]\&quot; используется если symbol не определен. | [optional] 
**broker_symbol** | **str** | Пара Биржа:Тикер | [optional] 
**exchange** | **str** | Биржа | [optional] 
**_date** | **str** | Дата и время (UTC) закрытия заявки | [optional] 
**board** | **str** | Код режима торгов | [optional] 
**qty_units** | **int** | Количество (штуки) | [optional] 
**qty_batch** | **int** | Количество (лоты) | [optional] 
**qty** | **int** | Количество (лоты) | [optional] 
**price** | **float** | Цена | [optional] 
**side** | **str** | Направление сделки. Купля либо продажа. | [optional] 
**existing** | **bool** | True - для данных из \&quot;снепшота\&quot;, то есть из истории. False - для новых событий | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

