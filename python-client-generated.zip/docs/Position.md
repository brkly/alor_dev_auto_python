# Position

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**symbol** | **str** | Тикер (Код финансового инструмента) | [optional] 
**broker_symbol** | **str** | Пара Биржа:Тикер | [optional] 
**exchange** | **str** | Биржа | [optional] 
**avg_price** | **float** | Средняя цена | [optional] 
**qty_units** | **float** | Количество (штуки) | [optional] 
**open_units** | **float** | Количество открытых позиций (штуки) | [optional] 
**lot_size** | **float** | Размер лота | [optional] 
**short_name** | **str** | Короткое наименование | [optional] 
**qty_t0** | **float** |  | [optional] 
**qty_t1** | **float** |  | [optional] 
**qty_t2** | **float** |  | [optional] 
**qty_t_future** | **float** | Количество (штуки) | [optional] 
**qty_t0_batch** | **float** |  | [optional] 
**qty_t1_batch** | **float** |  | [optional] 
**qty_t2_batch** | **float** |  | [optional] 
**qty_t_future_batch** | **float** | Количество (лоты) | [optional] 
**qty_batch** | **float** | Количество (лоты) | [optional] 
**open_qty_batch** | **float** |  | [optional] 
**qty** | **float** | Количество (лоты) | [optional] 
**open** | **float** |  | [optional] 
**unrealised_pl** | **float** |  | [optional] 
**is_currency** | **bool** | True для валютных остатков (денег), false - для торговых инструментов | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

