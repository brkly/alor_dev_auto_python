# Symbol

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**symbol** | **str** | Тикер (Код финансового инструмента) | [optional] 
**exchange** | **str** | Биржа | [optional] 
**description** | **str** | Короткое описание на русском языке | [optional] 
**ask** | **float** | Аск | [optional] 
**bid** | **float** | Бид | [optional] 
**prev_close_price** | **float** | Цена предыдущего закрытия | [optional] 
**last_price** | **float** | Последняя цена | [optional] 
**last_price_timestamp** | **float** | UTC-timestamp для значения поля \&quot;last_price\&quot; | [optional] 
**change** | **float** | Разность цены и цены предыдущего закрытия | [optional] 
**change_percent** | **float** | Относительное изменение цены | [optional] 
**high_price** | **float** | Максимальная цена | [optional] 
**low_price** | **float** | Минимальная цена | [optional] 
**accrued_int** | **int** | Начислено | [optional] 
**accrued_interest** | **int** | Начислено | [optional] 
**volume** | **float** | Объём | [optional] 
**open_interest** | **float** |  | [optional] 
**open_price** | **float** | Цена открытия | [optional] 
**_yield** | **int** |  | [optional] 
**lotsize** | **float** | Размер лота | [optional] 
**lotvalue** | **float** |  | [optional] 
**facevalue** | **float** |  | [optional] 
**type** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

