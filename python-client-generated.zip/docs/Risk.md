# Risk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**portfolio** | **str** | Идентификатор клиентского портфеля | [optional] 
**exchange** | **str** | Биржа | [optional] 
**portfolio_evaluation** | **float** | Общая стоимость портфеля | [optional] 
**portfolio_liquidation_value** | **float** | Стоимость ликвидного портфеля | [optional] 
**initial_margin** | **float** | Начальная маржа | [optional] 
**minimal_margin** | **float** | Минимальная маржа | [optional] 
**corrected_margin** | **float** | Скорректированная маржа | [optional] 
**risk_coverage_ratio_one** | **float** | НПР1 | [optional] 
**risk_coverage_ratio_two** | **float** | НПР2 | [optional] 
**risk_category_id** | **int** | Категория риска | [optional] 
**client_type** | **str** | Тип клиента | [optional] 
**has_forbidden_positions** | **bool** | Имеются ли запретные позиции | [optional] 
**has_negative_quantity** | **bool** | Имеются ли отрицательные количества | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

