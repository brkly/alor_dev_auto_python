# History

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**history** | [**list[HistoryObject]**](HistoryObject.md) |  | [optional] 
**next** | **int** | Время (UTC) начала следующей свечи | [optional] 
**prev** | **int** | Время (UTC) начала предыдущей свечи | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

